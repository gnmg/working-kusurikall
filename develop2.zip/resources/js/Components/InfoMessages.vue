<template>
    <div>
        <div class="px-6 py-4 bg-gray-200 border border-gray-300 sm:rounded-lg shadow-sm mb-6">
            <div class="max-w-2xl text-sm text-gray-600">
                <slot/>
            </div>
        </div>
    </div>
</template>

<script>
export default {}
</script>
